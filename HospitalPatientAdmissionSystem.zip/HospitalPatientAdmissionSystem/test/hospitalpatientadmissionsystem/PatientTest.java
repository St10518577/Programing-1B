/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package hospitalpatientadmissionsystem;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Sibiy
 */
public class PatientTest {
    



    // 1. Test that a Patient can be created
    @Test
    public void testPatientCreation() {

        Patient patient = new Patient(
                "P001",
                "John",
                "Smith",
                35,
                "Male",
                "Flu",
                PatientCategory.OUTPATIENT
        );

        assertNotNull(patient);
    }

    // 2. Test that an Inpatient can be created
    @Test
    public void testInpatientCreation() {

        Inpatient inpatient = new Inpatient(
                "P002",
                "David",
                "Nkosi",
                42,
                "Male",
                "Pneumonia",
                PatientCategory.INPATIENT,
                "W01",
                ""
        );

        assertNotNull(inpatient);
        assertTrue(inpatient instanceof Patient);
    }

    // 3. Test patient registration
    @Test
    public void testRegisterPatient() {

        PatientManager manager = new PatientManager();

        Patient patient = new Patient(
                "P003",
                "Sarah",
                "Mokoena",
                25,
                "Female",
                "Flu",
                PatientCategory.OUTPATIENT
        );

        assertTrue(manager.registerPatient(patient));
        assertNotNull(manager.findPatient("P003"));
    }

    // 4. Test duplicate Patient ID
    @Test
    public void testDuplicatePatientId() {

        PatientManager manager = new PatientManager();

        Patient patient1 = new Patient(
                "P004",
                "John",
                "Smith",
                30,
                "Male",
                "Flu",
                PatientCategory.OUTPATIENT
        );

        Patient patient2 = new Patient(
                "P004",
                "Peter",
                "Jones",
                40,
                "Male",
                "Asthma",
                PatientCategory.OUTPATIENT
        );

        assertTrue(manager.registerPatient(patient1));
        assertFalse(manager.registerPatient(patient2));
    }

    // 5. Test searching for a patient
    @Test
    public void testSearchPatient() {

        PatientManager manager = new PatientManager();

        Patient patient = new Patient(
                "P005",
                "Mary",
                "Dlamini",
                28,
                "Female",
                "Headache",
                PatientCategory.OUTPATIENT
        );

        manager.registerPatient(patient);

        assertNotNull(manager.findPatient("P005"));
        assertNull(manager.findPatient("P999"));
    }

    // 6. Test updating a patient
    @Test
    public void testUpdatePatient() {

        PatientManager manager = new PatientManager();

        Patient patient = new Patient(
                "P006",
                "James",
                "Mokoena",
                20,
                "Male",
                "Flu",
                PatientCategory.OUTPATIENT
        );

        manager.registerPatient(patient);

        boolean updated = manager.updatePatient(
                "P006",
                "James",
                "Nkosi",
                21,
                "Male",
                "Pneumonia",
                PatientCategory.INPATIENT
        );

        assertTrue(updated);
        assertNotNull(manager.findPatient("P006"));
    }

    // 7. Test deleting a patient
    @Test
    public void testDeletePatient() {

        PatientManager manager = new PatientManager();

        Patient patient = new Patient(
                "P007",
                "Peter",
                "Zulu",
                45,
                "Male",
                "Flu",
                PatientCategory.OUTPATIENT
        );

        manager.registerPatient(patient);

        assertTrue(manager.deletePatient("P007"));
        assertNull(manager.findPatient("P007"));
    }

    // 8. Test patient count
    @Test
    public void testPatientCount() {

        PatientManager manager = new PatientManager();

        Patient patient1 = new Patient(
                "P008",
                "John",
                "Smith",
                30,
                "Male",
                "Flu",
                PatientCategory.OUTPATIENT
        );

        Patient patient2 = new Patient(
                "P009",
                "Mary",
                "Jones",
                25,
                "Female",
                "Asthma",
                PatientCategory.EMERGENCY
        );

        manager.registerPatient(patient1);
        manager.registerPatient(patient2);

        assertEquals(2, manager.getPatientCount());
    }

    // 9. Test inpatient count
    @Test
    public void testInpatientCount() {

        PatientManager manager = new PatientManager();

        Patient inpatient = new Inpatient(
                "P010",
                "David",
                "Nkosi",
                42,
                "Male",
                "Pneumonia",
                PatientCategory.INPATIENT,
                "W01",
                ""
        );

        manager.registerPatient(inpatient);

        assertEquals(1, manager.getInpatientCount());
    }

    // 10. Test outpatient count
    @Test
    public void testOutpatientCount() {

        PatientManager manager = new PatientManager();

        Patient patient = new Patient(
                "P011",
                "Sarah",
                "Mokoena",
                25,
                "Female",
                "Flu",
                PatientCategory.OUTPATIENT
        );

        manager.registerPatient(patient);

        assertEquals(1, manager.getOutpatientCount());
    }

    // 11. Test emergency count
    @Test
    public void testEmergencyCount() {

        PatientManager manager = new PatientManager();

        Patient patient = new Patient(
                "P012",
                "Peter",
                "Zulu",
                50,
                "Male",
                "Injury",
                PatientCategory.EMERGENCY
        );

        manager.registerPatient(patient);

        assertEquals(1, manager.getEmergencyCount());
    }

    // 12. Test total number of beds
    @Test
    public void testTotalBeds() {

        BedManager bedManager = new BedManager();

        assertEquals(20, bedManager.getTotalBedCount());
    }

    // 13. Test bed allocation
    @Test
    public void testBedAllocation() {

        BedManager bedManager = new BedManager();

        Inpatient inpatient = new Inpatient(
                "P013",
                "David",
                "Nkosi",
                42,
                "Male",
                "Pneumonia",
                PatientCategory.INPATIENT,
                "W01",
                ""
        );

        assertTrue(bedManager.assignBed(inpatient, "B01"));
        assertEquals(1, bedManager.getOccupiedBedCount());
    }

    // 14. Test that an occupied bed cannot be allocated again
    @Test
    public void testOccupiedBedCannotBeAllocatedAgain() {

        BedManager bedManager = new BedManager();

        Inpatient inpatient1 = new Inpatient(
                "P014",
                "John",
                "Smith",
                35,
                "Male",
                "Flu",
                PatientCategory.INPATIENT,
                "W01",
                ""
        );

        Inpatient inpatient2 = new Inpatient(
                "P015",
                "Peter",
                "Zulu",
                40,
                "Male",
                "Asthma",
                PatientCategory.INPATIENT,
                "W01",
                ""
        );

        assertTrue(bedManager.assignBed(inpatient1, "B01"));
        assertFalse(bedManager.assignBed(inpatient2, "B01"));
    }

    // 15. Test releasing a bed
    @Test
    public void testReleaseBed() {

        BedManager bedManager = new BedManager();

        Inpatient inpatient = new Inpatient(
                "P016",
                "James",
                "Mokoena",
                30,
                "Male",
                "Flu",
                PatientCategory.INPATIENT,
                "W01",
                ""
        );

        bedManager.assignBed(inpatient, "B02");

        assertEquals(1, bedManager.getOccupiedBedCount());

        assertTrue(bedManager.releaseBed("B02"));

        assertEquals(0, bedManager.getOccupiedBedCount());
    }

    // 16. Test that an unavailable bed cannot be released
    @Test
    public void testReleaseAvailableBed() {

        BedManager bedManager = new BedManager();

        assertFalse(bedManager.releaseBed("B03"));
    }
}
    