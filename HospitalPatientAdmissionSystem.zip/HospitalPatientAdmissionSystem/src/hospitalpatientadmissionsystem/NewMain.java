/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package hospitalpatientadmissionsystem;

import java.util.Scanner;

public class NewMain {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        PatientManager patientManager = new PatientManager();
        BedManager bedManager = new BedManager();
        ReportManager reportManager = new ReportManager(bedManager,patientManager);

        int choice;

        do {
            System.out.println("\n===== HOSPITAL PATIENT ADMISSION SYSTEM =====");
            System.out.println("1. Register Patient");
            System.out.println("2. Search Patient");
            System.out.println("3. Update Patient");
            System.out.println("4. Delete Patient");
            System.out.println("5. Display All Patients");
            System.out.println("6. Display Bed Layout");
            System.out.println("7. Allocate Bed");
            System.out.println("8. Release Bed");
            System.out.println("9. Display Reports");
            System.out.println("10. Exit");
            System.out.print("Enter your choice: ");

            choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {

                case 1:
                    System.out.println("\n===== REGISTER PATIENT =====");

                    System.out.print("Enter Patient ID: ");
                    String patientId = scanner.nextLine();

                    System.out.print("Enter First Name: ");
                    String firstName = scanner.nextLine();

                    System.out.print("Enter Last Name: ");
                    String lastName = scanner.nextLine();

                    System.out.print("Enter Age: ");
                    int age = scanner.nextInt();
                    scanner.nextLine();

                    System.out.print("Enter Gender: ");
                    String gender = scanner.nextLine();

                    System.out.print("Enter Medical Condition: ");
                    String medicalCondition = scanner.nextLine();

                    System.out.println("\nSelect Patient Category:");
                    System.out.println("1. INPATIENT");
                    System.out.println("2. OUTPATIENT");
                    System.out.println("3. EMERGENCY");
                    System.out.print("Enter category: ");

                    int categoryChoice = scanner.nextInt();
                    scanner.nextLine();

                    PatientCategory category = null;

                    switch (categoryChoice) {

                        case 1:
                            category = PatientCategory.INPATIENT;
                            break;

                        case 2:
                            category = PatientCategory.OUTPATIENT;
                            break;

                        case 3:
                            category = PatientCategory.EMERGENCY;
                            break;

                        default:
                            System.out.println("Invalid category.");
                            break;
                    }

                    if (category != null) {

                        Patient patient;

                        if (category == PatientCategory.INPATIENT) {

                            System.out.print("Enter Ward Number: ");
                            String wardNumber = scanner.nextLine();

                            patient = new Inpatient(
                                    patientId,
                                    firstName,
                                    lastName,
                                    age,
                                    gender,
                                    medicalCondition,
                                    category,
                                    wardNumber,
                                    ""
                            );

                        } else {

                            patient = new Patient(
                                    patientId,
                                    firstName,
                                    lastName,
                                    age,
                                    gender,
                                    medicalCondition,
                                    category
                            );
                        }

                        if (patientManager.registerPatient(patient)) {
                            System.out.println("Patient registered successfully.");
                        } else {
                            System.out.println("Patient ID already exists.");
                        }
                    }

                    break;

                case 2:
                    System.out.println("\n===== SEARCH PATIENT =====");

                    System.out.print("Enter Patient ID: ");
                    String searchId = scanner.nextLine();

                    Patient foundPatient = patientManager.findPatient(searchId);

                    if (foundPatient != null) {
                        foundPatient.displayDetails();
                    } else {
                        System.out.println("Patient not found.");
                    }

                    break;

                case 3:
                    System.out.println("\n===== UPDATE PATIENT =====");

                    System.out.print("Enter Patient ID: ");
                    String updateId = scanner.nextLine();

                    Patient patientToUpdate = patientManager.findPatient(updateId);

                    if (patientToUpdate == null) {
                        System.out.println("Patient not found.");
                        break;
                    }

                    System.out.print("Enter new First Name: ");
                    String newFirstName = scanner.nextLine();

                    System.out.print("Enter new Last Name: ");
                    String newLastName = scanner.nextLine();

                    System.out.print("Enter new Age: ");
                    int newAge = scanner.nextInt();
                    scanner.nextLine();

                    System.out.print("Enter new Gender: ");
                    String newGender = scanner.nextLine();

                    System.out.print("Enter new Medical Condition: ");
                    String newCondition = scanner.nextLine();

                    System.out.println("\nSelect new Patient Category:");
                    System.out.println("1. INPATIENT");
                    System.out.println("2. OUTPATIENT");
                    System.out.println("3. EMERGENCY");
                    System.out.print("Enter category: ");

                    int newCategoryChoice = scanner.nextInt();
                    scanner.nextLine();

                    PatientCategory newCategory = null;

                    switch (newCategoryChoice) {

                        case 1:
                            newCategory = PatientCategory.INPATIENT;
                            break;

                        case 2:
                            newCategory = PatientCategory.OUTPATIENT;
                            break;

                        case 3:
                            newCategory = PatientCategory.EMERGENCY;
                            break;

                        default:
                            System.out.println("Invalid category.");
                            break;
                    }

                    if (newCategory != null) {

                        if (patientManager.updatePatient(
                                updateId,
                                newFirstName,
                                newLastName,
                                newAge,
                                newGender,
                                newCondition,
                                newCategory)) {

                            System.out.println("Patient updated successfully.");

                        } else {
                            System.out.println("Patient could not be updated.");
                        }
                    }

                    break;

                case 4:
                    System.out.println("\n===== DELETE PATIENT =====");

                    System.out.print("Enter Patient ID: ");
                    String deleteId = scanner.nextLine();

                    if (patientManager.deletePatient(deleteId)) {
                        System.out.println("Patient deleted successfully.");
                    } else {
                        System.out.println("Patient not found.");
                    }

                    break;

                case 5:
                    System.out.println("\n===== ALL PATIENTS =====");

                    patientManager.displayAllPatients();

                    break;

                case 6:
                    System.out.println("\n===== BED LAYOUT =====");

                    bedManager.displayBeds();

                    break;

                case 7:
                    System.out.println("\n===== ALLOCATE BED =====");

                    System.out.print("Enter Inpatient ID: ");
                    String inpatientId = scanner.nextLine();

                    Patient patientForBed = patientManager.findPatient(inpatientId);

                    if (patientForBed == null) {
                        System.out.println("Patient not found.");
                        break;
                    }

                    if (!(patientForBed instanceof Inpatient)) {
                        System.out.println("Only inpatients can be allocated a bed.");
                        break;
                    }

                    Inpatient inpatient = (Inpatient) patientForBed;

                    System.out.print("Enter Bed Number: ");
                    String bedNumber = scanner.nextLine();

                    if (bedManager.assignBed(inpatient, bedNumber)) {
                        System.out.println("Bed allocated successfully.");
                    } else {
                        System.out.println(
                                "Bed allocation failed. "
                                + "The bed may already be occupied or the inpatient may already have a bed."
                        );
                    }

                    break;

                case 8:
                    System.out.println("\n===== RELEASE BED =====");

                    System.out.print("Enter Bed Number: ");
                    String releaseBedNumber = scanner.nextLine();

                    if (bedManager.releaseBed(releaseBedNumber)) {
                        System.out.println("Bed released successfully.");
                    } else {
                        System.out.println("Bed could not be released.");
                    }

                    break;

                case 9:
                    System.out.println("\n===== REPORTS =====");

                    reportManager.displayOccupancyReport();

                    break;

                case 10:
                    System.out.println("\nExiting system...");
                    break;

                default:
                    System.out.println("Invalid choice. Please try again.");
            }

        } while (choice != 10);

        scanner.close();
    }
}