package hospitalpatientadmissionsystem;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import hospitalpatientadmissionsystem.PatientCategory;
/**
 *
 * @author Sibiy
 */
public class PatientManager {
    private Patient[] patients;
private int patientCount;
public PatientManager() {
    patients = new Patient[100];
    patientCount = 0;
}
public boolean registerPatient(Patient patient) {

    // Check if the Patient ID already exists
    for (int i = 0; i < patientCount; i++) {
        if (patients[i].getPatientId().equals(patient.getPatientId())) {
            return false;
        }
    }

    // Add the patient
    patients[patientCount] = patient;
    patientCount++;

    return true;
}
public Patient findPatient(String patientId) {

    for (int i = 0; i < patientCount; i++) {
        if (patients[i].getPatientId().equals(patientId)) {
            return patients[i];
        }
    }

    return null;
}
public boolean updatePatient(String patientId, String firstName, String lastName,
                             int age, String gender, String medicalCondition,
                             PatientCategory category) {

    Patient patient = findPatient(patientId);

    if (patient == null) {
        return false;
    }

    patient.setFirstName(firstName);
    patient.setLastName(lastName);
    patient.setAge(age);
    patient.setGender(gender);
    patient.setMedicalCondition(medicalCondition);
    patient.setCategory(category);

    return true;
}
public boolean deletePatient(String patientId) {

    for (int i = 0; i < patientCount; i++) {

        if (patients[i].getPatientId().equals(patientId)) {

            // Move the patients after this one one position to the left
            for (int j = i; j < patientCount - 1; j++) {
                patients[j] = patients[j + 1];
            }

            patients[patientCount - 1] = null;
            patientCount--;

            return true;
        }
    }

    return false;
}
public void displayAllPatients() {

    if (patientCount == 0) {
        System.out.println("No patients registered.");
        return;
    }

    for (int i = 0; i < patientCount; i++) {
        System.out.println("----------------------------");
        patients[i].displayDetails();
    }

    System.out.println("----------------------------");
}
public int getPatientCount() {
    return patientCount;
}

public int getInpatientCount() {

    int count = 0;

    for (int i = 0; i < patientCount; i++) {
        if (patients[i].getCategory() == PatientCategory.INPATIENT) {
            count++;
        }
    }

    return count;
}

public int getOutpatientCount() {

    int count = 0;

    for (int i = 0; i < patientCount; i++) {
        if (patients[i].getCategory() == PatientCategory.OUTPATIENT) {
            count++;
        }
    }

    return count;
}

public int getEmergencyCount() {

    int count = 0;

    for (int i = 0; i < patientCount; i++) {
        if (patients[i].getCategory() == PatientCategory.EMERGENCY) {
            count++;
        }
    }

    return count;
}
    
}
