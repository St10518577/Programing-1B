/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hospitalpatientadmissionsystem;

/**
 *
 * @author Sibiy
 */
public class BedManager {
    

    private Bed[] beds;

    public BedManager() {
        beds = new Bed[20];

        for (int i = 0; i < beds.length; i++) {
            String bedNumber = String.format("B%02d", i + 1);
            beds[i] = new Bed(bedNumber);
        }
    }
        public boolean allocateBed(String bedNumber, String patientId) {

    for (int i = 0; i < beds.length; i++) {

        if (beds[i].getBedNumber().equals(bedNumber)) {

            if (beds[i].isOccupied()) {
                return false;
            }

            beds[i].allocateBed(patientId);
            return true;
        }
    }

    return false;
}
        public boolean releaseBed(String bedNumber) {

    for (int i = 0; i < beds.length; i++) {

        if (beds[i].getBedNumber().equals(bedNumber)) {

            if (!beds[i].isOccupied()) {
                return false;
            }

            String patientId = beds[i].getPatientId();

            beds[i].releaseBed();

            return true;
        }
    }

    return false;
}
   

        public void displayBeds() {

    System.out.println("===== BED LAYOUT =====");

    for (int i = 0; i < beds.length; i++) {
        beds[i].displayBedDetails();

        if ((i + 1) % 5 == 0) {
            System.out.println();
        }
    }
        }
        public boolean assignBed(Inpatient inpatient, String bedNumber) {

    // Check if the inpatient already has a bed
    if (inpatient.getBedNumber() != null && !inpatient.getBedNumber().isEmpty()) {
        return false;
    }

    // Try to allocate the bed
    if (allocateBed(bedNumber, inpatient.getPatientId())) {
        inpatient.setBedNumber(bedNumber);
        return true;
    }

    return false;
}
        public int getOccupiedBedCount() {

    int count = 0;

    for (int i = 0; i < beds.length; i++) {
        if (beds[i].isOccupied()) {
            count++;
        }
    }

    return count;
}

public int getTotalBedCount() {
    return beds.length;
}
    }

        
        
    

    
    

