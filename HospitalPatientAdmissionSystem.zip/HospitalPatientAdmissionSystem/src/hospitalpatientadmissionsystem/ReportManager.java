package hospitalpatientadmissionsystem;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Sibiy
 */
public class ReportManager {
   

    private BedManager bedManager;
    private PatientManager patientManager;

    public ReportManager(BedManager bedManager, PatientManager patientManager) {
        this.bedManager = bedManager;
        this.patientManager = patientManager;
    }

    public void displayOccupancyReport() {

    int totalPatients = patientManager.getPatientCount();
    int inpatients = patientManager.getInpatientCount();
    int outpatients = patientManager.getOutpatientCount();
    int emergencyPatients = patientManager.getEmergencyCount();

    int occupiedBeds = bedManager.getOccupiedBedCount();
    int totalBeds = bedManager.getTotalBedCount();
    int availableBeds = totalBeds - occupiedBeds;

    double occupancyPercentage =
            ((double) occupiedBeds / totalBeds) * 100;

    System.out.println("\n===== HOSPITAL REPORT =====");

    System.out.println("\n--- PATIENT STATISTICS ---");
    System.out.println("Total Patients: " + totalPatients);
    System.out.println("Inpatients: " + inpatients);
    System.out.println("Outpatients: " + outpatients);
    System.out.println("Emergency Patients: " + emergencyPatients);

    System.out.println("\n--- BED STATISTICS ---");
    System.out.println("Total Beds: " + totalBeds);
    System.out.println("Occupied Beds: " + occupiedBeds);
    System.out.println("Available Beds: " + availableBeds);
    System.out.println("Occupancy Percentage: " + occupancyPercentage + "%");
}
}