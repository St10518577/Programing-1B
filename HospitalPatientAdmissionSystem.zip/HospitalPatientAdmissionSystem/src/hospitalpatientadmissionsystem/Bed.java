package hospitalpatientadmissionsystem;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Sibiy
 */
public class Bed {
    

    private String bedNumber;
    private boolean occupied;
    private String patientId;

    public Bed(String bedNumber) {
        this.bedNumber = bedNumber;
        this.occupied = false;
        this.patientId = "";
    }

    public String getBedNumber() {
        return bedNumber;
    }

    public boolean isOccupied() {
        return occupied;
    }

    public String getPatientId() {
        return patientId;
    }

    public void allocateBed(String patientId) {
        this.occupied = true;
        this.patientId = patientId;
    }

    public void releaseBed() {
        this.occupied = false;
        this.patientId = "";
    }

    public void displayBedDetails() {
        if (occupied) {
            System.out.println(bedNumber + " - Occupied by Patient " + patientId);
        } else {
            System.out.println(bedNumber + " - Available");
        }
    }
}