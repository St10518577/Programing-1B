/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package newpackage;

/**
 *
 * @author Sibiy
 */
public abstract class BeverageSales extends Beverage implements IBeverage {
    

    // Constructor
    public BeverageSales(String beverageType, String City, int totalSales) {
        super(City, beverageType, totalSales);
    }

    // Interface method
    public String getbeveragetype() {
        return City;
    }

    // Interface method
    @Override
    public String getCity() {
        return City;
    }

    // Interface method
    @Override
    public int gettotalSales() {
        return totalSales;
    }

    // Overriding the abstract method
    
    public void printReport() {
        System.out.println("BeverageType: " + beverageType);
        System.out.println("City: " + City);
        System.out.println("Total Sales: " + totalSales);
    }
}


    