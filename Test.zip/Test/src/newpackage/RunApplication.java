/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package newpackage;
import java.util.Scanner;
/**
 *
 * @author Sibiy
 */
public class RunApplication {


    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        System.out.print("Enter Beverage type: ");
        String consoleType = input.nextLine();

        System.out.print("Enter City name: ");
        String storeName = input.nextLine();

        System.out.print("Enter total amount of sales: ");
        int totalSales = input.nextInt();

        BeverageSales sales = new BeverageSales(
                beverageType,
                City,
                totalSales
                
        

        System.out.println();

        sales.printReport();

        input.close();
    }
}
    
    

