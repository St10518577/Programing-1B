/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package newpackage;

/**
 *
 * @author Sibiy
 */
public abstract class Beverage {

    protected String City;
    protected String beverageType;
    int totalSales;
    
      public Beverage(String City,String beverageType,int totalSales){
          this.City = City;
          this.beverageType = beverageType;
          this.totalSales = totalSales;
      }
          // Abstract Method
         public abstract void printreport();
            
    }
 