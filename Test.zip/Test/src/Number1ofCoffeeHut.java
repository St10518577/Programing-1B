/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author Sibiy
 */
public class Number1ofCoffeeHut {

    

    public static void main(String[] args) {

        //  Single array for city names
        String[] cities = {
            "Cape Town",
            "Port Elizabeth",
            "Pretoria"
        };

        // array for beverage names
        String[] beverages = {
            "Coffee",
            "Tea",
            "Boba Tea"
        };

        //  2D array for monthly sales
        int[][] sales = {
            {500, 300, 125},
            {450, 250, 100},
            {480, 175, 120}
        };

        int grandTotal = 0;

        // This is the report heading
        System.out.println("==============================================");
        System.out.println("       NUMBER 1 COFFEE HUT BEVERAGE REPORT");
        System.out.println("==============================================");

        System.out.printf("%-20s %-10s %-10s %-10s %-10s%n",
                "City", "Coffee", "Tea", "Boba Tea", "Total");

        System.out.println("--------------------------------------------------------------");

        // Display sales and calculate total for each city
        for (int i = 0; i < cities.length; i++) {

            int cityTotal = 0;

            System.out.printf("%-20s", cities[i]);

            for (int j = 0; j < sales[i].length; j++) {

                System.out.printf("%-10d", sales[i][j]);

                cityTotal += sales[i][j];
            }

            System.out.printf("%-10d%n", cityTotal);

            grandTotal += cityTotal;
        }

        System.out.println("--------------------------------------------------------------");
        System.out.println("Total sales for all cities: " + grandTotal);
        System.out.println("==============================================");
    }
}

